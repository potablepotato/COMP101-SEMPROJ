# COMP101-SEMPROJ
COMP101 Semester Project "Highschool 2: Electric Boogaloo"

If you've worked on the project at home, please make sure to comment in your commits (uploads) what changes you've made to the code. Thanks!
